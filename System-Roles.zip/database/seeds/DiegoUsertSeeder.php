<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class DiegoUsertSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Realizar la configuracion de los datos falsos
      //  factory(App\User::class, 80)->create();
    }
}
