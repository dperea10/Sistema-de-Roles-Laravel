

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Usuarios</div>


                <div class="card-body">
                    <div class=" table-responsive p-0" style="weigth: auto; height: 600px;">

                      <!--td> <a class="m-2 float-right btn btn-outline-primary" href="<?php echo e(route('register')); ?>"> Registrar</a></td--> 

                          
                                <?php echo Form::open(['route' => 'admin.user.index','method'=>'GET', 'class'=> 'float-right navbar-form form-inline navbar-left pull-right', 'role'=>'search' ]); ?>

                             
                              <div class="form-group">
                                <?php echo Form::text('name', null, ['class'=>'form-control','placeholder'=>'Buscar por nombre']); ?>

                              </div>
                                 <button class="btn btn-outline-success " type="submit">Buscar</button>
                                <?php echo Form::close(); ?>

                          
                          

                              <table class="table table-striped">
                                <thead>
                                  <tr>
                                    <th >#</th>
                                    <th >Nombre</th>
                                    <th >Correo</th>
                                    <th >Roles</th>
                                    <th >Acciones</th>
                                   
                                    <th colspan="3"></th>
                                    
                                  </tr>
                                </thead>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                   
                                  <tr>
                                    <th scope="row"> <?php echo e($user->id); ?></th>
                                    <td> <?php echo e($user->name); ?></td>
                                    <td> <?php echo e($user->email); ?></td>
                                    <td> <?php echo e(implode(',', $user->roles()->get()->pluck('name')->toArray())); ?></td>
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-users')): ?>   
                                   
                                    <td><a href="<?php echo e(route('admin.user.edit', $user->id)); ?>"><button type="button" class="btn btn-outline-success">Actualizar</button></a></td>
                                  <?php endif; ?>
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-users')): ?>
                                    <td><a href="<?php echo e(route('admin.user.destroy', $user)); ?>" method="POST" class="float-left">
                                      
                                     <?php echo e(method_field('DELETE')); ?>

                                      <button type="button" class="btn btn-outline-danger">Eliminar</button></a></td>    
                                  </tr>
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
            
                        </div>  
                </div>

            </div>

        </div>

    </div>

</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\System-Roles\resources\views/admin/user/index.blade.php ENDPATH**/ ?>