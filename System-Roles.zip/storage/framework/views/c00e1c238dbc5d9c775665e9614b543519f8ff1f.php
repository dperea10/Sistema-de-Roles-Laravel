

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Clientes</div>


                <div class="card-body">
                    <div class=" table-responsive p-0" style="weigth: auto; height: 600px;">

                      <td> <a class="m-2 float-right btn btn-outline-primary" href="<?php echo e(route('admin.client.create')); ?>"> Registrar</a></td> 

                          
                                <?php echo Form::open(['route' => 'admin.client.index','method'=>'GET', 'class'=> 'float-right navbar-form form-inline navbar-left pull-right', 'role'=>'search' ]); ?>

                             
                              <div class="form-group">
                                <?php echo Form::text('name', null, ['class'=>'form-control','placeholder'=>'Buscar por nombre']); ?>

                              </div>
                                 <button class="btn btn-outline-success " type="submit">Buscar</button>
                                <?php echo Form::close(); ?>

                          
                          

                              <table class="table table-striped">
                                <thead>
                                  <tr>
                                    <th >#</th>
                                    <th >Nombre</th>
                                    <th >Documento</th>
                                    <th >Correo</th>
                                    <th >Direccion</th>
                                   
                                    <th colspan="3"></th>
                                    
                                  </tr>
                                </thead>
                                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                   
                                  <tr>
                                    <th scope="row"> <?php echo e($client->id); ?></th>
                                    <td> <?php echo e($client->name); ?></td>
                                    <td> <?php echo e($client->documento); ?></td>
                                    <td> <?php echo e($client->email); ?></td>
                                    <td> <?php echo e($client->address); ?></td>
                                    
                                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-clients')): ?>   
                                   
                                    <td><a href="<?php echo e(route('admin.client.edit', $client->id)); ?>"><button type="button" class="btn btn-outline-success">Actualizar</button></a></td>
                                  
                                 
                                    <td><a href="<?php echo e(route('admin.client.destroy', $client->id)); ?>" method="POST"class="btn btn-outline-danger float-left"><?php echo method_field('DELETE'); ?>
                                     Eliminar</a></td>  
                                     <a href="<?php echo e(route('admin.client.destroy', $client->id)); ?>">  
                                  </tr>
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
            
                        </div>  
                </div>

            </div>

        </div>

    </div>

</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\System-Roles\resources\views/admin/client/index.blade.php ENDPATH**/ ?>